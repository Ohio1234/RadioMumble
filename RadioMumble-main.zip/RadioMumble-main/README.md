# Radio og Mumble

I skal bare smide dem ind i jeres recources filer og skrive

start mumble-voip
start rp-radio

i server_resources.cfg
